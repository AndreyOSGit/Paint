module.exports = {
    sayHello: function() {
        return 'hello'
    },
    addNumbers: function(value1,value2) {
        return value1 + value2
    }
};