let objCanvasJSON;
let activeTabNumber;
let canvas;
let strokeColor;
let lineWidth;
let num;
let currentFigure;

window.onload = function() {
    init();
};

function init() {
    activeTabNumber = 1;
    let objCanvas = {
        Tab1: ['layer1canvas1']
    };
    objCanvasJSON = JSON.stringify(objCanvas);
    num = document.getElementsByClassName('btn-focus');
    canvas = document.getElementById('layer1canvas1');
    currentFigure = 'circle';
    addEventListeners(canvas);
    initFromLS();
    initUI();

}
function initUI() {
    document.getElementById("changeSize").innerHTML = lineWidth;
    document.getElementById('changeSize').value = lineWidth;
    document.getElementById('showColor').style.background = strokeColor;
    document.getElementById('showColor').innerHTML = strokeColor;
}

function initFromLS() {
    lineWidth = localStorage.getItem('lineWidth') ? localStorage.getItem('lineWidth') : 50;
    strokeColor = localStorage.getItem('color') ? localStorage.getItem('color') : "black";
}

function addEventListeners(canvas) {

    document.getElementById("canvas-wrapper").addEventListener('mousedown', mouseDownHandler);
    //canvas.addEventListener('mousedown', mouseDownHandler);
    document.getElementById('btnPressed').addEventListener('click', buttonPressed);

    document.getElementById('changeSize').addEventListener('mousemove', updateSize);
    document.getElementById('changeColor').addEventListener('keypress', changeColor);

    document.getElementById('square').addEventListener('click', function() {
        currentFigure = 'square';
    
    });
    document.getElementById('circle').addEventListener('click', function() {
        currentFigure = 'circle';
    });
    document.getElementById('hexagon').addEventListener('click', function() {
        currentFigure = 'hexagon';
    });

    document.getElementById('clear').addEventListener('click', function() {
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
    });

    document.getElementById('addNewTab').addEventListener('click', addNewTabFunc);

    document.getElementById('addNewLayer').addEventListener('click', addNewLayerFunc);
};

function buttonPressed() {
    btnPressed.classList.toggle('btn-focus');
}

function mouseDownHandler(event) {
    const canvas = event.target;
    console.log(event);
    if (canvas && canvas.getContext && num.length > 0) {
        const ctx = canvas.getContext('2d');
        //ctx.clearRect(0, 0, 1400, 790);
        ctx.beginPath();
        ctx.strokeStyle = strokeColor;
        ctx.lineTo(event.offsetX, event.offsetY);
        ctx.lineWidth = lineWidth;
        ctx.lineCap = "round";
        ctx.stroke();
        console.log(event.offsetX, event.offsetY);
    }
    getCoords();
    canvas.addEventListener('mousemove', mouseMoveHandler);
    canvas.addEventListener('mouseup', mouseUpHandler);
}

function mouseMoveHandler(event) {
    const canvas = event.target;
    if (canvas && canvas.getContext && num.length > 0) {

        const ctx = canvas.getContext('2d');
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = lineWidth;
        ctx.lineTo(event.offsetX, event.offsetY);
        ctx.stroke();
    }
    getCoords();
}

function mouseUpHandler(event) {
    const canvas = event.target;
    drawFigure(event);
    canvas.removeEventListener('mousemove', mouseMoveHandler);
}

function getCoords() {
    document.getElementById('mouseX').innerHTML = `: ${event.clientX}`;
    document.getElementById('mouseY').innerHTML = `: ${event.clientY}`;
}

function updateSize() {
    var sizeInputRange = document.getElementById("changeSize").value;
    document.getElementById("size").innerHTML = sizeInputRange;
    lineWidth = sizeInputRange;
    localStorage.setItem('lineWidth', sizeInputRange);
}

function changeColor(event) {
    if (event.keyCode === 13) {
        let newColor = document.getElementById('changeColor');
        const showColor = document.getElementById('showColor');
        showColor.style.background = newColor.value;
        if (showColor.style.background === newColor.value) {
            strokeColor = newColor.value;
            localStorage.setItem('color', strokeColor)
            document.getElementById('showColor').innerHTML = localStorage.getItem('color');
        } else {
            console.log('error color')
        }
    }
}

function drawFigure(event) {
    const canvas = event.target;
    switch (currentFigure) {
        case 'circle' : {
            if(canvas && canvas.getContext && num.length === 0)  {
                const ctx = canvas.getContext('2d');
                let radiusCircle = lineWidth;
                document.getElementById('changeSize').addEventListener('mousemove', updateSize);
                localStorage.setItem('lineWidth', lineWidth);
                ctx.beginPath();
                ctx.arc(event.offsetX, event.offsetY, radiusCircle,0,Math.PI*2,true); // Внешняя окружность
                ctx.stroke();

            }
            break;
        }
        case 'hexagon' : {
            if(canvas && canvas.getContext && num.length === 0)  {
                const ctx = canvas.getContext('2d');
                document.getElementById('changeSize').addEventListener('mousemove', updateSize);
                localStorage.setItem('lineWidth', lineWidth);
                ctx.lineWidth = lineWidth;
                ctx.beginPath();
                ctx.moveTo(event.offsetX,event.offsetY);
                ctx.lineTo((event.offsetX)+50,(event.offsetY));
                ctx.lineTo((event.offsetX)+75,(event.offsetY)+25);
                ctx.lineTo((event.offsetX)+50,(event.offsetY)+50);
                ctx.lineTo((event.offsetX),(event.offsetY)+50);
                ctx.lineTo((event.offsetX)-25,(event.offsetY)+25);
                ctx.closePath();
                ctx.stroke();
            }
            break;
        }
        case 'square' : {
            if(canvas && canvas.getContext && num.length === 0)  {
                const ctx = canvas.getContext('2d');
                ctx.lineWidth = lineWidth;
                document.getElementById('changeSize').addEventListener('mousemove', updateSize);
                localStorage.setItem('lineWidth', lineWidth);
                ctx.strokeStyle = strokeColor;
                ctx.strokeRect(event.offsetX, event.offsetY, ctx.lineWidth, ctx.lineWidth);
            }
            break;
        }
    }
}

function showHideCanvas(e) {
    let thisCanvas1 = e.target.id;
    thisCanvas = String(thisCanvas1.substr(5));
    let checkbox1 = document.getElementsByName("chboxs");
    let displayCanvas = "none";
    for(let i = 0; i < checkbox1.length; i++) { 
        if (checkbox1[i].checked){
            console.log(checkbox1[i])
            displayCanvas = "block";
        }
    }
    document.getElementById(thisCanvas).style.display = displayCanvas;
}